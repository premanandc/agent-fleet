# Agent Fleet

A simple LangGraph-based agent for breaking down complex tasks into actionable steps.

## Features

- **Provider-agnostic**: Supports both OpenAI and Anthropic LLMs
- **Smart task analysis**: Automatically determines if a task needs breakdown
- **Simple workflow**: Uses LangGraph for clear state management
- **Easy configuration**: Switch providers via simple parameters

## Project Structure

```
agent-fleet/
   src/
      llm/
         factory.py          # LLM provider factory
      agents/
         task_breakdown.py   # Main task breakdown agent
      models/
          state.py            # State definitions
   main.py                      # Example usage
   pyproject.toml               # Dependencies
   .env                         # API keys (create from .env.example)
```

## Setup

1. **Install dependencies**:
   ```bash
   uv sync
   ```

2. **Configure API keys**:
   ```bash
   cp .env.example .env
   # Edit .env and add your API keys
   ```

   You need at least one of:
   - `ANTHROPIC_API_KEY` for Claude models
   - `OPENAI_API_KEY` for GPT models

## Usage

### Run the examples:
```bash
python main.py
```

### Use in your code:
```python
from src.agents.task_breakdown import TaskBreakdownAgent

# Using Anthropic (Claude)
agent = TaskBreakdownAgent(provider="anthropic")

# Or using OpenAI (GPT)
agent = TaskBreakdownAgent(provider="openai")

# Run the agent
result = agent.run("Build a REST API with authentication")

print(f"Needs breakdown: {result['needs_breakdown']}")
print(f"Analysis: {result['analysis']}")
for i, step in enumerate(result['steps'], 1):
    print(f"{i}. {step}")
```

## How It Works

The agent uses a LangGraph state machine with two main nodes:

1. **Analyze**: Determines if the task is simple or needs breakdown
2. **Breakdown**: If needed, breaks the task into clear, actionable steps

The workflow:
```
[Start] -> [Analyze Task] -> [Break Down?]
                                  |
                                  v Yes
                            [Break Down Task] -> [End]
                                  |
                                  v No
                                [End]
```

## Configuration

You can customize the agent behavior:

```python
agent = TaskBreakdownAgent(
    provider="anthropic",           # "openai" or "anthropic"
    model="claude-3-5-sonnet-20241022",  # Optional: specific model
    temperature=0.7                 # Optional: generation temperature
)
```

## Dependencies

- `langchain-core` - Core LangChain abstractions
- `langchain-openai` - OpenAI integration
- `langchain-anthropic` - Anthropic integration
- `langgraph` - State machine framework
- `python-dotenv` - Environment variable management
